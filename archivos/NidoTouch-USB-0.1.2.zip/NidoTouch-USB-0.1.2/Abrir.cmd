@echo off
setlocal DisableDelayedExpansion
java -jar "%~dp0NidoTouch-USB.jar"
set "resultado=%errorlevel%"
if not "%resultado%"=="0" (
  echo Abre el manual. Este asistente requiere Java 17 o posterior de escritorio.
  pause
)
exit /b %resultado%
