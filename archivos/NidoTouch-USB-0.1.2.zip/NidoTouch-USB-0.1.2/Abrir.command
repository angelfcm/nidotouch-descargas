#!/bin/sh
java -jar "$(dirname "$0")/NidoTouch-USB.jar"
resultado=$?
if [ "$resultado" -ne 0 ]; then
  echo 'Abre el manual. Este asistente requiere Java 17 o posterior de escritorio.'
  read -r continuar
fi
exit "$resultado"
